
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `advance_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advance_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `month` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `advance_salary` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `advance_salaries` WRITE;
/*!40000 ALTER TABLE `advance_salaries` DISABLE KEYS */;
INSERT INTO `advance_salaries` VALUES (1,4,'June','2024','500000','2024-07-06 12:03:41',NULL),(2,2,'June','2024','100000','2024-07-06 12:04:31',NULL);
/*!40000 ALTER TABLE `advance_salaries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `attendences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `attend_status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `attendences` WRITE;
/*!40000 ALTER TABLE `attendences` DISABLE KEYS */;
INSERT INTO `attendences` VALUES (1,1,'1970-01-01','Absent','2024-07-09 04:20:16','2024-07-09 04:20:16'),(2,2,'1970-01-01','Absent','2024-07-09 04:20:16','2024-07-09 04:20:16'),(3,3,'1970-01-01','present','2024-07-09 04:20:16','2024-07-09 04:20:16'),(4,4,'1970-01-01','Leave','2024-07-09 04:20:16','2024-07-09 04:20:16');
/*!40000 ALTER TABLE `attendences` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Jam tangan','2024-07-06 12:06:52',NULL),(2,'Makanan Ringan','2024-07-06 12:07:03',NULL),(3,'Sembako','2024-07-06 12:07:19',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `shopname` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `account_holder` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_branch` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (7,'Gayle Macejkovic','meaghan.hackett@example.org','+1-332-463-1429','ZycRZZ9','7DkYkqy','upload/customer/image_1720291878.jpg','QrmHb','5753287','HFy','3oj','EUvoz','2024-07-06 11:51:18','2024-07-06 11:53:01'),(8,'Erin McLaughlin','swolf@example.org','1-805-495-2377','YO7Wn5r','lY5nmi3','upload/customer/image_1720291879.jpg','AJJFr','6399563','C9M','m6X','IL6eM','2024-07-06 11:51:19','2024-07-06 11:53:01'),(9,'Cristobal Larkin','keenan.bosco@example.net','1-540-574-0085','YBiwo7f','DOCLv5b','upload/customer/image_1720291883.jpg','sEFsd','8708656','Jqd','Xen','ynsZr','2024-07-06 11:51:23','2024-07-06 11:53:01'),(11,'Alvis Reinger','jarrod68@example.org','(631) 693-8934','Fcb6sYF','oVHUduR','upload/customer/image_1720291956.jpg','dZpbt','8565490','Py7','8H0','Dv3zM','2024-07-06 11:52:36','2024-07-06 11:53:01'),(12,'Lavonne Lockman','vergie14@example.org','(239) 253-1486','rGxqo7p','VzuZtT0','upload/customer/image_1720291981.jpg','l0aaJ','8010272','hah','A6v','dTsRf','2024-07-06 11:53:01','2024-07-06 11:53:01'),(14,'Maynard Rodriguez','bgutkowski@example.org','(951) 788-6850','AB7WGLa','Fe3dhkx','upload/customer/image_1720292096.jpg','VfAqT','5442617','2m8','MkI','cMEIf','2024-07-06 11:54:56','2024-07-06 11:56:16'),(16,'Camila Bailey','mariane.king@example.net','620.779.3869','MWIs3iy','uMmoLS4','upload/customer/image_1720292159.jpg','eIApc','8489136','aBj','yN8','87xVq','2024-07-06 11:55:59','2024-07-06 11:56:16'),(17,'Judah Casper','bwitting@example.org','+1-518-985-9538','MRPhI4Y','whKYU9x','upload/customer/image_1720292170.jpg','KoG1D','3934121','BIs','np7','nY36N','2024-07-06 11:56:10','2024-07-06 11:56:16'),(18,'Garnet Stehr','ctrantow@example.com','318-317-9277','sAtOmTz','JoFuqfI','upload/customer/image_1720292176.jpg','LL8ro','7628999','XI8','L6e','O3iDY','2024-07-06 11:56:16','2024-07-06 11:56:16'),(19,'Prof. Bo Braun','zachariah.turner@example.com','(260) 422-3129','rjlZ1WL','4lIEOKx','upload/customer/image_1720292205.jpg','nEubt','4646927','p6Q','0nV','LqSDg','2024-07-06 11:56:45','2024-07-06 11:56:54'),(20,'Laurel Bernhard','graham.autumn@example.com','757-483-6781','S75cYtg','00O7im4','upload/customer/image_1720292207.jpg','ULPaS','8565388','yW4','TMN','Csa8U','2024-07-06 11:56:47','2024-07-06 11:56:54'),(21,'Randi Harvey','prohaska.elena@example.net','+1.651.970.7183','w3Naz0k','QuU5GDg','upload/customer/image_1720292209.jpg','243yl','8078258','QVi','4bZ','bDHJ4','2024-07-06 11:56:49','2024-07-06 11:56:54'),(22,'Peter Thompson','ilubowitz@example.com','+1 (678) 283-0751','VdNC5Rg','80hGkdi','upload/customer/image_1720292211.jpg','a5FL7','3517753','iQ2','9pQ','PH2ve','2024-07-06 11:56:51','2024-07-06 11:56:54'),(23,'Keegan Adams','kaci.schulist@example.net','+1 (281) 953-1409','2Pbvwve','j1bnIC7','upload/customer/image_1720292212.jpg','A0rZ6','9460930','Zdw','WTD','qfCSA','2024-07-06 11:56:52','2024-07-06 11:56:54'),(24,'Mrs. Willie Kilback','grant.virgie@example.com','1-703-249-8931','G0vW7v6','YYatNaG','upload/customer/image_1720292214.jpg','13dz1','6361102','dVL','heheh','v5zfm','2024-07-06 11:56:54','2024-07-12 21:52:09'),(25,'Siska novelia','siska@gmail.com','0897443334556','Ds Singonegoro kecamatan Jiken','Shopee','upload/customer/1804029001241729.png','Pay Later','4324343','Mandiri','Livin by Mandiri','Blora','2024-07-08 09:28:46','2024-07-12 21:54:57');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `salary` varchar(255) DEFAULT NULL,
  `vacation` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Asri Puji Astutik','asri@gmail.com','0895360889600','Dk Sentonorejo kec jiken kab Blora','1','upload/employee/1803855821152940.jpg','1200000','3','Blora','2024-07-06 11:36:07',NULL),(2,'Ananda Dimmas','dimmas@gmail.com','089776335446','dk Cabak kec jiken','4','upload/employee/1803855914166194.png','1400000','3','Blora','2024-07-06 11:37:36',NULL),(3,'Ahnad Nuril Anwar','nuril@gmail.com','089644733822','Dk Sentonorejo kec jiken kab Blora','1','upload/employee/1803855981085264.png','1100000','1','Blora','2024-07-06 11:38:39',NULL),(4,'Aziz','aziz@gmail.com','085773883993','desa ngawen kec ngawen','2','upload/employee/1803856083040641.png','1200000','4','Blora','2024-07-06 11:40:17',NULL);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `details` text NOT NULL,
  `amount` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2024_06_28_012647_create_employees_table',1),(6,'2024_06_28_064407_create_customers_table',1),(7,'2024_06_29_062545_create_suppliers_table',1),(8,'2024_06_29_165022_create_advance_salaries_table',1),(9,'2024_06_30_060758_create_pay_salaries_table',1),(10,'2024_06_30_162815_create_attendences_table',1),(11,'2024_07_02_064453_create_categories_table',1),(12,'2024_07_02_105339_create_products_table',1),(13,'2024_07_04_033228_create_expenses_table',1),(14,'2024_07_04_055526_create_pos_table',1),(15,'2024_07_04_113704_create_shoppingcart_table',1),(16,'2024_07_09_021947_create_orders_table',2),(23,'2024_07_09_023458_create_order_details_table',3),(24,'2024_07_09_175417_create_permission_tables',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (6,'App\\Models\\User',15),(7,'App\\Models\\User',14),(8,'App\\Models\\User',9),(9,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `unitcost` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_details` WRITE;
/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
INSERT INTO `order_details` VALUES (1,3,13,'2','9500','21850.00',NULL,NULL),(2,3,12,'1','23000','26450.00',NULL,NULL),(3,4,9,'1','12000','13800.00',NULL,NULL);
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `order_date` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `total_product` varchar(255) NOT NULL,
  `sub_total` varchar(255) DEFAULT NULL,
  `vat` varchar(255) DEFAULT NULL,
  `invoice_no` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `pay` varchar(255) DEFAULT NULL,
  `due` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,25,'09-July-2024','pending','1','9500.00','1425.00','EPOS62521618','10925.00','HandCash','10925','0','2024-07-09 03:00:23','2024-07-12 23:41:50'),(2,25,'09-July-2024','complete','1','23000.00','3450.00','EPOS79154498','26450.00','HandCash','26450','0','2024-07-09 03:06:37','2024-07-12 23:40:52'),(3,25,'13-July-2024','pending','3','42000.00','6300.00','EPOS55289630','48300.00','HandCash','1000000','-951700','2024-07-12 23:14:50',NULL),(4,24,'13-July-2024','complete','1','12000.00','1800.00','EPOS76127905','13800.00',NULL,'13500','300','2024-07-12 23:43:33','2024-07-12 23:44:08');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pay_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `salary_month` varchar(255) DEFAULT NULL,
  `paid_amount` varchar(255) DEFAULT NULL,
  `advance_salary` varchar(255) DEFAULT NULL,
  `due_salary` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pay_salaries` WRITE;
/*!40000 ALTER TABLE `pay_salaries` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_salaries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'pos.menu','web','pos','2024-07-11 10:11:01','2024-07-11 10:11:01'),(2,'add.expense','web','expense','2024-07-11 10:12:26','2024-07-11 10:12:26'),(3,'expense.store','web','expense','2024-07-11 10:12:43','2024-07-11 10:12:43'),(4,'today.expense','web','expense','2024-07-11 10:12:58','2024-07-11 10:12:58'),(5,'expense.edit','web','expense','2024-07-11 10:13:19','2024-07-11 10:13:19'),(6,'expense.update','web','expense','2024-07-11 10:13:34','2024-07-11 10:13:34'),(7,'month.expense','web','expense','2024-07-11 10:13:59','2024-07-11 10:13:59'),(8,'year.expense','web','expense','2024-07-11 10:14:13','2024-07-11 10:14:13'),(9,'all.employee','web','employee','2024-07-11 10:14:48','2024-07-11 10:14:48'),(10,'add.employee','web','employee','2024-07-11 10:15:00','2024-07-11 10:15:00'),(11,'employee.store','web','employee','2024-07-11 10:15:13','2024-07-11 10:15:13'),(12,'employee.edit','web','employee','2024-07-11 10:15:26','2024-07-11 10:15:26'),(13,'employee.update','web','employee','2024-07-11 10:15:37','2024-07-11 10:15:37'),(14,'employee.delete','web','employee','2024-07-11 10:15:53','2024-07-11 10:15:53'),(15,'all.customer','web','customer','2024-07-11 10:20:25','2024-07-11 10:20:25'),(16,'add.customer','web','customer','2024-07-11 10:20:45','2024-07-11 10:20:45'),(17,'customer.store','web','customer','2024-07-11 10:21:00','2024-07-11 10:21:00'),(18,'customer.edit','web','customer','2024-07-11 10:21:16','2024-07-11 10:21:16'),(19,'customer.update','web','customer','2024-07-11 10:21:31','2024-07-11 10:21:31'),(20,'customer.delete','web','customer','2024-07-11 10:21:42','2024-07-11 10:21:42'),(21,'all.supplier','web','supplier','2024-07-11 10:22:01','2024-07-11 10:22:01'),(22,'add.supplier','web','supplier','2024-07-11 10:22:11','2024-07-11 10:22:11'),(23,'supplier.store','web','supplier','2024-07-11 10:22:25','2024-07-11 10:22:25'),(24,'supplier.edit','web','supplier','2024-07-11 10:22:42','2024-07-11 10:22:42'),(25,'supplier.update','web','supplier','2024-07-11 10:22:55','2024-07-11 10:22:55'),(26,'supplier.delete','web','supplier','2024-07-11 10:23:09','2024-07-11 10:23:09'),(27,'supplier.detail','web','supplier','2024-07-11 10:23:20','2024-07-11 10:23:20'),(28,'pay.salary','web','salary','2024-07-11 10:24:05','2024-07-11 10:24:05'),(29,'pay.now.salary','web','salary','2024-07-11 10:24:17','2024-07-11 10:24:17'),(30,'employee.salary.store','web','salary','2024-07-11 10:24:27','2024-07-11 10:24:27'),(31,'month.salary','web','salary','2024-07-11 10:24:57','2024-07-11 10:24:57'),(32,'history.salary','web','salary','2024-07-11 10:25:08','2024-07-11 10:25:08'),(33,'employee.attend.list','web','attendence','2024-07-11 10:25:27','2024-07-11 10:25:27'),(34,'add.employee.attend','web','attendence','2024-07-11 10:25:43','2024-07-11 10:25:43'),(35,'employee.attend.store','web','attendence','2024-07-11 10:25:59','2024-07-11 10:25:59'),(36,'employee.attend.edit','web','attendence','2024-07-11 10:26:13','2024-07-11 10:26:13'),(37,'employee.attend.update','web','attendence','2024-07-11 10:26:24','2024-07-11 10:26:24'),(38,'employee.attend.details','web','attendence','2024-07-11 10:26:36','2024-07-11 10:26:36'),(39,'all.category','web','category','2024-07-11 10:26:51','2024-07-11 10:26:51'),(40,'category.store','web','category','2024-07-11 10:27:02','2024-07-11 10:27:02'),(41,'category.edit','web','category','2024-07-11 10:27:15','2024-07-11 10:27:15'),(42,'category.update','web','category','2024-07-11 10:27:26','2024-07-11 10:27:26'),(43,'category.delete','web','category','2024-07-11 10:27:40','2024-07-11 10:27:40'),(44,'all.product','web','product','2024-07-11 10:27:57','2024-07-11 10:27:57'),(45,'add.product','web','product','2024-07-11 10:28:08','2024-07-11 10:28:08'),(46,'product.store','web','product','2024-07-11 10:28:21','2024-07-11 10:28:21'),(47,'product.edit','web','product','2024-07-11 10:28:34','2024-07-11 10:28:34'),(48,'product.update','web','product','2024-07-11 10:28:45','2024-07-11 10:28:45'),(49,'product.delete','web','product','2024-07-11 10:28:57','2024-07-11 10:28:57'),(50,'product.barcode','web','product','2024-07-11 10:29:14','2024-07-11 10:29:14'),(51,'final.invoice','web','orders','2024-07-11 10:29:57','2024-07-11 10:29:57'),(52,'pending.order','web','orders','2024-07-11 10:30:22','2024-07-11 10:30:22'),(53,'order.details','web','orders','2024-07-11 10:30:34','2024-07-11 10:30:34'),(54,'order.status.update','web','orders','2024-07-11 10:30:45','2024-07-11 10:30:45'),(55,'complete.order','web','orders','2024-07-11 10:30:57','2024-07-11 10:30:57'),(56,'stock.manage','web','orders','2024-07-11 10:31:21','2024-07-11 10:31:21'),(57,'orderInvoice','web','stock','2024-07-11 10:31:36','2024-07-11 10:31:36'),(58,'employee.menu','web','employee','2024-07-11 22:59:18','2024-07-11 22:59:18'),(59,'customer.menu','web','customer','2024-07-11 22:59:35','2024-07-11 22:59:35'),(60,'supplier.menu','web','supplier','2024-07-11 22:59:46','2024-07-11 22:59:46'),(61,'salary.menu','web','salary','2024-07-11 22:59:59','2024-07-11 22:59:59'),(62,'attendance.menu','web','attendence','2024-07-11 23:00:14','2024-07-11 23:00:14'),(63,'category.menu','web','category','2024-07-11 23:00:27','2024-07-11 23:00:27'),(64,'product.menu','web','product','2024-07-11 23:00:38','2024-07-11 23:00:38'),(65,'expense.menu','web','expense','2024-07-11 23:00:50','2024-07-11 23:00:50'),(66,'order.menu','web','orders','2024-07-11 23:01:04','2024-07-11 23:01:04'),(67,'stock.menu','web','stock','2024-07-11 23:01:16','2024-07-11 23:01:16'),(68,'roles.menu','web','roles','2024-07-11 23:01:26','2024-07-11 23:01:26'),(69,'all.user','web','roles','2024-07-12 23:08:00','2024-07-12 23:08:00'),(70,'add.user','web','admin','2024-07-12 23:08:17','2024-07-12 23:08:17'),(71,'admin.menu','web','admin','2024-07-12 23:08:41','2024-07-12 23:08:41');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pos` WRITE;
/*!40000 ALTER TABLE `pos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_garage` varchar(255) DEFAULT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_store` varchar(255) DEFAULT NULL,
  `buying_date` varchar(255) DEFAULT NULL,
  `expire_date` varchar(255) DEFAULT NULL,
  `buying_price` varchar(255) DEFAULT NULL,
  `selling_price` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'abu brown',1,1,'PC0001','Jiken','upload/product/1803858836052636.webp','5','2024-07-07','2024-07-08','40000','62000','2024-07-06 12:24:03','2024-07-09 07:36:42'),(2,'Hagger Original',1,1,'PC0002','Jiken','upload/product/1803858935138241.webp','2','2024-07-07','2024-07-07','167000','231000','2024-07-06 12:25:36','2024-07-09 07:36:32'),(3,'Black Analog',1,1,'PC0003','Jiken','upload/product/1803859000998678.webp','4','2024-07-07','2024-07-07','40000','56000','2024-07-06 12:26:39','2024-07-09 07:36:22'),(4,'Nardin Original',1,1,'PC0004','Jiken','upload/product/1803859062028193.webp','4','2024-07-07','2024-07-07','230000','310000','2024-07-06 12:27:37','2024-07-09 07:36:05'),(5,'Espoir Original',1,1,'PC0005','Jiken','upload/product/1803859142842937.webp','2','2024-07-07','2024-07-07','410000','500000','2024-07-06 12:28:55','2024-07-09 07:35:46'),(6,'Limestone Original',1,1,'PC0006','Jiken','upload/product/1803859260682717.webp','5','2024-07-07',NULL,'510000','530000','2024-07-06 12:30:47','2024-07-09 07:34:13'),(7,'Limestone',1,1,'PC0007','Jiken','upload/product/1803859321267938.webp','3','2024-07-07',NULL,'120000','130000','2024-07-06 12:31:45','2024-07-09 07:35:23'),(8,'Aarong Natural',3,2,'PC0008','Jiken','upload/product/1803859415172727.webp','15','2024-07-07','2024-08-10','30000','51000','2024-07-06 12:33:14','2024-07-09 07:33:54'),(9,'arna dalno milk',2,2,'PC0009','JIken','upload/product/1803859481622525.webp','11','2024-07-07','2024-08-10','8000','12000','2024-07-06 12:34:18','2024-07-12 23:44:08'),(10,'Nazilsail 5 Kg',3,1,'PC0010','Jiken','upload/product/1803859541101103.webp','8','2024-07-07','2024-08-10','40000','62000','2024-07-06 12:35:14','2024-07-09 07:33:35'),(11,'Bombay Sweet',3,2,'PC0011','Jiken','upload/product/1803859599507484.webp','6','2024-07-07','2024-08-10','12000','17000','2024-07-06 12:36:10','2024-07-09 07:33:27'),(12,'Minyak Diploma',3,2,'PC0012','JIken','upload/product/1803859653298660.webp','6','2024-07-07','2024-08-10','13000','23000','2024-07-06 12:37:01','2024-07-09 07:33:18'),(13,'family tea',2,2,'PC0013','Jiken','upload/product/1803859715861814.webp','12','2024-07-07','2024-08-10','6000','9500','2024-07-06 12:38:01','2024-07-09 07:33:08');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,6),(1,8),(1,9),(2,7),(2,8),(2,9),(3,7),(3,8),(3,9),(4,7),(4,8),(4,9),(5,7),(5,8),(5,9),(6,7),(6,8),(6,9),(7,7),(7,8),(7,9),(8,7),(8,8),(8,9),(9,8),(9,9),(10,8),(10,9),(11,8),(11,9),(12,8),(12,9),(13,8),(13,9),(14,8),(14,9),(15,6),(15,8),(15,9),(16,6),(16,8),(16,9),(17,6),(17,8),(17,9),(18,6),(18,8),(18,9),(19,6),(19,8),(19,9),(20,6),(20,8),(20,9),(21,7),(21,8),(21,9),(22,7),(22,8),(22,9),(23,7),(23,8),(23,9),(24,7),(24,8),(24,9),(25,7),(25,8),(25,9),(26,7),(26,8),(26,9),(27,7),(27,8),(27,9),(28,8),(28,9),(29,8),(29,9),(30,8),(30,9),(31,8),(31,9),(32,8),(32,9),(33,8),(33,9),(34,8),(34,9),(35,8),(35,9),(36,8),(36,9),(37,8),(37,9),(38,8),(38,9),(39,6),(39,8),(39,9),(40,6),(40,8),(40,9),(41,6),(41,8),(41,9),(42,6),(42,8),(42,9),(43,6),(43,8),(43,9),(44,6),(44,8),(44,9),(45,6),(45,8),(45,9),(46,6),(46,8),(46,9),(47,6),(47,8),(47,9),(48,6),(48,8),(48,9),(49,6),(49,8),(49,9),(50,6),(50,8),(50,9),(51,6),(51,8),(51,9),(52,6),(52,8),(52,9),(53,6),(53,8),(53,9),(54,6),(54,8),(54,9),(55,6),(55,8),(55,9),(56,6),(56,8),(56,9),(57,7),(57,8),(57,9),(58,8),(58,9),(59,6),(59,8),(59,9),(60,7),(60,8),(60,9),(61,8),(61,9),(62,8),(62,9),(63,6),(63,8),(63,9),(64,6),(64,8),(64,9),(65,7),(65,8),(65,9),(66,6),(66,8),(66,9),(67,7),(67,8),(67,9),(68,8),(68,9);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (6,'Kasir','web','2024-07-12 21:25:17','2024-07-12 21:25:17'),(7,'Admin','web','2024-07-12 21:25:25','2024-07-12 21:25:25'),(8,'Manager','web','2024-07-12 21:25:35','2024-07-12 21:25:35'),(9,'Manajemen','web','2024-07-12 21:26:10','2024-07-12 21:26:10');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `shopping_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopping_cart` (
  `identifier` varchar(255) NOT NULL,
  `instance` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`identifier`,`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `shopping_cart` WRITE;
/*!40000 ALTER TABLE `shopping_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopping_cart` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `shopname` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `account_holder` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_branch` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'ANG27 OnlineShop','ang@gmail.com','086774885994','Dk Sentonorejo kec jiken kab Blora','Olshop Ang27 Grosiran','upload/supplier/1803857340605556.png','Expert Supplier','Grosir','2323232','BRI','Dana','Blora','2024-07-06 12:00:16',NULL),(2,'Supriyyy Market','supp@gmail.com','087669550440','Dk Sentonorejo kec jiken kab Blora','Supryy market','upload/supplier/1803857482764882.png','Expert Supplier','market place','423423423','BRI','Mandiri','Blora','2024-07-06 12:02:31',NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Fahrudin','udin@gmail.com','0895360889600','202407130441WhatsApp Image 2024-07-10 at 10.17.49_c10a3352.jpg',NULL,'$2y$12$JKVFJOnIhiLPGQCTTtG19.OFnU8BcjJ189DDLYftYq/y5g73R1Gya','gUfMIPGKW5fwLzTOP6xssvAE6vumq8qnEdptqIrNAs2OH4wZqicXWBUO9UiX','2024-07-06 00:12:31','2024-07-12 21:41:10'),(9,'asri puji','asri@gmail.com','0897665774884','202407120246WhatsApp Image 2024-06-26 at 19.14.37_28f46fef.jpg',NULL,'$2y$12$4maLbtXjIBSL6B3DCqSEyuV.h/oo/7fd8XjudvDaaluF6VGyg9WIq','MC2hZyRRKSGpHlEGGdyvh49fLNFgcJMfPGbxyIbR8zUP3EUq4rS74CWCjTzC','2024-07-11 19:41:00','2024-07-11 19:55:31'),(14,'admin','admin@gmail.com','087665335554',NULL,NULL,'$2y$12$pncppZfMZYEhXOX7RSSNtescYF/JBGEJMGqEaPs5dJPoz7JgTeY0q',NULL,'2024-07-12 21:42:13','2024-07-12 21:42:13'),(15,'Kasir','kasir@gmail.com','08977558866997',NULL,NULL,'$2y$12$IBUmgHm/IbtG7NoLUcKj4u4ILPZSNykO9oz5qOBAymFaoveClRX2i',NULL,'2024-07-12 21:42:52','2024-07-12 21:42:52');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

